#define  _CRT_SECURE_NO_WARNINGS 
#include <iostream>

using namespace std;

//����
class AbstractCar{
public:
	virtual void run() = 0;
};

//���ڳ�
class Dazhong :public AbstractCar{
public:
	virtual void run(){
		cout << "���ڳ�����..." << endl;
	}
};


// ������
class Tuolaji :public AbstractCar{
public:
	virtual void run(){
		cout << "����������.." << endl;
	}
}; 

/*
class Person1 : public Tuolaji{
public: 
	void Doufeng(){//����
			run();
	}
 };

class Person2 : public Dazhong{
public:
	void Doufeng(){//����
		run();
	}
};
*/
//����ʹ�����
class Person{
public:
	AbstractCar*car;

public:

	void setCar(AbstractCar*car){
		this->car = car;
	}
	void Doufeng(){
		this->car->run();
		
	}
	~Person(){
		if (this->car != NULL) {
			delete this->car;
		}
	}

};
void test01()
{
	Person* p = new Person;
	p->setCar(new Dazhong);
	p->Doufeng();


	p->setCar(new Tuolaji);
	p->Doufeng();
	delete p;
}

int main(){
	test01();
	return 0;
}